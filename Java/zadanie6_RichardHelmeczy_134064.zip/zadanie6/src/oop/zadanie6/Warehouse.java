package oop.zadanie6;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Warehouse {
    private Set<Product> products;

    public Warehouse() {
        products = new HashSet<>();
    }

    public void addProduct(Product p) throws ProductAlreadyExistsException {
        if (products.contains(p)) {
            throw new ProductAlreadyExistsException("Product s ID '" + p.getId() + "' sa v sklade už nachádza.");
        }
        products.add(p);
    }

    public void removeProduct(String id) throws ProductNotFoundException {
        Iterator<Product> it = products.iterator();

        while (it.hasNext()) {
            Product n = it.next();
            if (n.getId().equals(id)) {
                it.remove();
                return;
            }
        }

        throw new ProductNotFoundException("Product s ID '" + id + "' sa v sklade nenachádza.");
    }

    public int getProductCount() {
        return products.size();
    }
}